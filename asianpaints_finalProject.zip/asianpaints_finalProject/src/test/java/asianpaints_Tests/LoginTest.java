package asianpaints_Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

import com.aventstack.extentreports.*;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

import io.github.bonigarcia.wdm.WebDriverManager;

import java.time.Duration;

public class LoginTest {

    WebDriver driver;
    WebDriverWait wait;
    ExtentReports extent;
    ExtentTest test;

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        wait = new WebDriverWait(driver, Duration.ofSeconds(20));

        ExtentSparkReporter reporter = new ExtentSparkReporter("reports/LoginTestReport.html");
        extent = new ExtentReports();
        extent.attachReporter(reporter);
    }

    @Test
    public void loginWithPhoneNumber() {
        test = extent.createTest("Asian Paints Login Test");

        driver.get("https://www.asianpaints.com/");
        test.info("Navigated to Asian Paints website");

        try {
            WebElement profileBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("/html/body/div[3]/div/div[1]/div/div/header/div[3]/div[4]/div[1]/span")));
            profileBtn.click();
            test.pass("Clicked on profile icon");

            WebElement phoneInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//*[@id='phoneInput']")));
            phoneInput.sendKeys("6309311329");
            test.pass("Entered phone number");

            WebElement proceedBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//*[@id='gigya-otp-send-code-form']/div[4]/div[1]")));
            proceedBtn.click();
            test.pass("Clicked on Proceed button");

            // === Wait for manual OTP entry ===
            test.info("Waiting 45 seconds for manual OTP entry...");
            Thread.sleep(45000); // User manually enters OTP within this time

            // === Auto-click on Login button ===
           /* WebElement loginBtn = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//*[@id='gigya-otp-login-form']/div[5]/div[3]")));
            loginBtn.click();
            test.pass("Clicked on Login button after OTP entry");*/

            // Optional: Add validation
            Thread.sleep(3000); // short wait after login
            test.pass("Login process attempted successfully");

        } catch (Exception e) {
            test.fail("Login test failed: " + e.getMessage());
        }
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
        extent.flush();
    }
}
